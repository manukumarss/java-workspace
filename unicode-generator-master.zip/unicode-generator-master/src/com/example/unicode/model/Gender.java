package com.example.unicode.model;

public enum Gender {
	MALE, FEMALE
}
